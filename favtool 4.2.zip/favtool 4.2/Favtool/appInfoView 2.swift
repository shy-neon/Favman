//
//  appInfoView.swift
//  Favtool
//
//  Created by Nicola Di Gregorio on 22/11/22.
//

import SwiftUI

struct appInfoView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct appInfoView_Previews: PreviewProvider {
    static var previews: some View {
        appInfoView()
    }
}
